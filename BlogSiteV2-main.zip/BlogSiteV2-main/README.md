did some changes to the auth w les apis (barsha changes)

#securinets application server-side

This repo contains the **securinetWriteups V2 server side application** backend.
